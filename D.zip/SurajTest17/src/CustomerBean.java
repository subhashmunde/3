package basic.web.app;

import java.sql.*;
import java.util.*;

public class CustomerBean implements java.io.Serializable {

	private String username;
	private String password;

	public final String getUserName() { return username; }
	public final void setUserName(String value) { username = value; }

	public final String getPassword() { return password; }
	public final void setPassword(String value) { password = value; }

	public boolean authenticate() throws SQLException {
		try(var con = DB.connect()){
			var pstmt = con.prepareStatement("select count(no) from admin where username=? and password=?");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			var rs = pstmt.executeQuery();
			rs.next();
			int count = rs.getInt(1);
			rs.close();
			pstmt.close();
			if(count == 1)
				return true;
				username = password = null;
			return false;
		}
	}

	public List<OrderEntry> getOrders() throws SQLException {
		var orders = new ArrayList<OrderEntry>();
		try(var con = DB.connect()){
			var pstmt = con.prepareStatement("select no, name, branch, crank, year from admin");
			
			var rs = pstmt.executeQuery();
			while(rs.next())
				orders.add(new OrderEntry(rs));
			rs.close();
			pstmt.close();
		}
		return orders;
	}


	public static class OrderEntry {
		
		private int number;
		private String sname;
		private String ebranch;
		private int crank;
		private int year;

		OrderEntry(ResultSet rs) throws SQLException {
			number = rs.getInt("no");
			sname = rs.getString("name");
			ebranch = rs.getString("branch");
			crank = rs.getInt("crank");
			year = rs.getInt("year");
		}

		public final int getNo() { return number; }

		public final String getName() { return sname; }

		public final String getBranch() { return ebranch; }

		public final int getCrankk() { return crank; }

		public final int getYear() { return year; }


	}
}

