package basic.web.app;

public class GreeterBean implements java.io.Serializable 
{

	private String person;
	private String branch;
	private String rank;
	private String year;

	public final String getPerson() { return person; }
	public final void setPerson(String value) { person = value; }

	public final String getBranch() { return branch; }
	public final void setBranch(String value) { branch = value; }

	public final String getRank() { return rank; }
	public final void setRank(String value) { rank = value; }

	public final String getYear() { return year; }
	public final void setYear(String value) { year = value; }


	public String getGreetingMessage1() 
	{
		return String.format("%s", person);
	}

	public String getGreetingMessage2() 
	{
		return String.format("%s", branch);
	}

	public String getGreetingMessage3() 
	{
		return String.format("%s", rank);
	}

	public String getGreetingMessage4() 
	{
		return String.format("%s", year);
	}
}

